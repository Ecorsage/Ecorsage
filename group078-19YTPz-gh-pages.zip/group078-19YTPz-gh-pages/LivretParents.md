# Livret aux parents

Dans un but pédagogique, nous avons réfléchi aux modes de communication qu'il nous faudrait mettre en place pour donner vie à ce projet. Pour atteindre notre objectif, il nous faut convaincre les parents, les professeurs, les directeurs d'école... et rendre visible la visée du projet qui dépasse le fait de faire planter des légumes à des enfants à l'école. 

Ce livret à destination des parents, présente notre projet et nos objectifs. 


![](/group078-19YTPz/assets/images/page01.jpg)

![](/group078-19YTPz/assets/images/page02.jpg) 

![](/group078-19YTPz/assets/images/page03.jpg)

![](/group078-19YTPz/assets/images/page04.jpg)

![](/group078-19YTPz/assets/images/page05.jpg)   

![](/group078-19YTPz/assets/images/page06.jpg)

![](/group078-19YTPz/assets/images/page07.jpg)

