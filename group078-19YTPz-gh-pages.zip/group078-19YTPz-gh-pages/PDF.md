# Tous nos documents

Vous retrouverez ici tous nos documents au format PDF.

## Notre note d'intention

<div class="aspect-ratio document">
  <object data="assets/pdf/Notedintention.pdf" type="application/pdf">
    <p>This browser does not support PDF! Click <a href="assets/pdf/a4.pdf">here</a> to download the file</p>
  </object>
</div>

## Notre Business Plan

<div class="aspect-ratio document">
  <object data="assets/pdf/BusinessPlan.pdf" type="application/pdf">
    <p>This browser does not support PDF! Click <a href="assets/pdf/a4.pdf">here</a> to download the file</p>
  </object>
</div>

## Notre Livret explicatif à l'intention des parents

<div class="aspect-ratio document">
  <object data="assets/pdf/LivretParents.pdf" type="application/pdf">
    <p>This browser does not support PDF! Click <a href="assets/pdf/a4.pdf">here</a> to download the file</p>
  </object>
</div>
