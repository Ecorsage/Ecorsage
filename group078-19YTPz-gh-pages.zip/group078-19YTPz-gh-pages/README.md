# A Great Transition project

This private repository is what powers your project's website at `https://thegreattransition.github.io/group[group_id]` where `[group_id]` is your group's secret ID.

> **NOTE: Please do not share this ID (and your website's address) with others if you wish to protect your project material before the final submission.**

You are here because you have accepted an invitation to collaborate on this private repository. Now head down to **[tutorial](tutorial.md)** to get started with editing your website.
