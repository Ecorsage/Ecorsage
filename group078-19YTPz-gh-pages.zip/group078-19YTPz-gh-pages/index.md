# Bienvenue 
## à tous les agriculteurs en herbe et autres cultivateurs de ville sur le site des p’tites mains vertes !

Ici, vous trouverez toutes les informations dont vous avez besoin pour vous familiariser avec ce projet, découvrir l’équipe derrière l'idée et les valeurs que nous souhaitons partager avec vous et vos enfants.

En vous souhaitant une bonne récole, 

_Les taupes matinales_
